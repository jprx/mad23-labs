# EntryBleed

People say KPTI helps stop micro-architectural side-channels... this belief is simply wrong.
Try out EntryBleed, a.k.a. CVE-2022-4543, a universal unpatched KASLR bypass on Linux systems
with KPTI! And the best part is you can easily implement a working attack that leaks you
KASLR base within seconds using the knowledge you have gained so far about prefetch sidechannels!

## Instructions

Before staring, make sure to run ./setup.sh. This will help set up the environment for you
so you can easily repack your newly compiled binaries into the minimal VM.

Take a look at the provided template in exploit.c. You just need to determine the lower and upper bounds
for the range of kernel virtual addresses to probe, fill out the code for the prefetch sidechannel, and
write the code that processes data (averages or threshold style both should work). Once you believe
you have a working attack that can leak KASLR base, send it to the /checker binary in the VM. If it is correct,
you will get a flag!
