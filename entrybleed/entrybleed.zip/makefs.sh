#!/bin/sh
if [ ! -d "./file_system" ] 
then
    echo "Make sure you ran setup.sh beforehand"
    exit 1
fi
cd $(pwd)/file_system && find . | cpio --create --format='newc'  > ../initramfs.cpio
cd .. && gzip -f initramfs.cpio
