file=initramfs.cpio
gzip -d $file.gz
mkdir -p file_system
cp -f $file ./file_system/$file
cd ./file_system && cpio -id < $file && rm $file && cd ..
./makefs.sh
