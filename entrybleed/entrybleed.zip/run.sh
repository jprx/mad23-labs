#!/bin/sh
qemu-system-x86_64 \
    -s \
    -m 4096M \
    -smp 2 \
    -nographic \
    -kernel "./bzImage" \
    -append "console=ttyS0 oops=panic loglevel=3 panic=-1 pti=on" \
    -netdev user,id=net \
    -device e1000,netdev=net \
    -no-reboot \
    -monitor /dev/null \
    -cpu host \
    -initrd "./initramfs.cpio.gz" \
    -enable-kvm
